/// <reference types="Cypress" />

describe('Clowre', function() {

  
      it('Form Builder ' , function()
      {
        cy.viewport('macbook-15')
        cy.clearCookies()
        cy.visit('http://192.168.0.182/login')

        cy.get('#accountId').type('sarvika-qa')
          .get('#username').type('aakarshan.sharma')
          .get('#password').type('test1234{enter}')
        
        cy.contains('FormBuilder').click().wait(300)
        // cy.get('[href="/formbuilder/forms/newform"]').click()
        //   .get('#name').type('automation2')
        // cy.contains('Next').click()
        //   .get('[data-id="blank_Temp_Default_One"]').click()
        //   .get('[type="submit"]').click().wait(300)

        cy.get('#search').click().type('automation2')
        cy.contains('Search').click().wait(300)
          .get('.MuiIconButton-edgeStart').click()
        
        cy.contains('Media').click()
        cy.contains('Explorer').click()

          .get('.name').click()

              const filePath = 'resume';
        cy.get('#resume_file').attachFile(filePath)
      })
    })