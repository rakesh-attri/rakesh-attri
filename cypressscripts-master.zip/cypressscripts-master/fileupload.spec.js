describe('SKU', function() {
  
  it('Item creation', function()
  {
    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://cpd.sarvika.com/admin/login')
      .get('#username').type('')
      .get('#password').type('')
      .get('.btn').click()
    cy.contains('ICT APP').click().wait(300)
      .get('.clip-cube-2.fa-4x').click().wait(300)
      .get('.btn-success').click().wait(300)
      .get('#product-sku').type('sku.title')
      .get('#product-name').type('sku.title')
    cy.contains('Product Design').click()
      .get(':nth-child(1) >>> .product-btn > .btn').click()
      .get('.box-color').eq(1).click()
      .get('#ajax-modal >>>> .close').click().wait(1000)
      .get('#view-front >>> .product-btn > .btn').click().wait(4000)
     
          
                                function repeat(){
                                cy.get('.fancybox-iframe')
                                  .then(function ($iframe) {
                                    const $body = $iframe.contents().find('body')

                                cy
                                  .wrap($body)
                                  .find('[title="dg-designer-0e4f5cc9157978404873814135811037484.jpg"]').click()
                              
                                cy
                                  .wrap($body)
                                  .find('#files-upload').invoke('attr', 'style' ,'dispaly:show').click()
                                //.find('[title="Insert"]').click()
                            })

                            //.get('.design-tools > .btn-primary > .glyphicon').click()
                          }
      
      repeat()
  })
})


