

describe('Title Validation', () => {
 const urls = ['https://cb.mypromomall.com/preview/channingbete/health-care/healthy-living' ,'https://cb.mypromomall.com/preview/channingbete/health-care/disease-management']
const cls = ['Healthy Living | Channing Bete' ,'Disease Management | Channing Bete']
  
    it(`Title`, () => {
       urls.forEach((url) => {
      cy.viewport(1920, 937)
      cy.visit(url).wait(900)
        
        cy.wrap(cls).spread(() => {
            cy.title().then(($val) => {

              expect($val).to.be.oneOf(cls)
                                       })
                                  })
    
})
    })
  })



