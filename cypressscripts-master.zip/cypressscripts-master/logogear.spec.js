describe('value update', function() {
  it('Template edit', function()
  {

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://www.mylogogear.com/staging/listvendors.admin')
      .get('[name="j_username"]').type('')
      .get('[name="j_password"]').type('{enter}').wait(900)

  function repeat(i){    
      cy.get('[name="s_vid"]').type(i)
      .get('[value="Search"]').click()
    cy.contains(i).invoke('removeAttr', 'target').click().wait(900)
    cy.contains('Templates').click().wait(200)
    cy.contains('Manage Templates').click({force:true}).wait(200)
      .get('#searchname').type('footer')
      .get('[name="display"]').click().wait(200)
    cy.contains('edit').click().wait(2000)

      .get('#VelocityEdit').click().type('<script type="text/javascript" src="assets/common_all_store.js?v=#springMessage(\'vm.itemTemplate.version\')"></script>')
      
      .get('[name="ok"]').click().wait(200)
      cy.visit('https://www.mylogogear.com/staging/listvendors.admin')
}
    const abs =['20160226009' ,'20160620001' ,'20160806001' ,'20160620009' ,'20160426002' ,'20160426007' ,'20160620004' ,'20160912005' ,'20160912002' ,'20160912001' ,'20160620008' ,'20160912007' ,'20160806005' ,'20160806009' ,'20161020006' ,'20161202001' ,'20160912003' ,'20170130001' ,'20161020008' ,'20160912009' ,'20151221005' ,'20161202003' ,'20161020002' ,'20161020009' ,'20161020004' ,'20161202002' ,'20161202007' ,'20161202006' ,'20170130003' ,'20170130002' ,'20161202008' ,'20161202004' ,'20170130005' ,'20170320001' ,'20160620007' ,'20170130006' ,'20170320003' ,'20160405005']

    abs.forEach((ab)  => {
    repeat(ab)

})
     })

})


// <script type="text/javascript" src="assets/common_all_store.js?v=#springMessage('vm.itemTemplate.version')"></script>