/// <reference types="Cypress" />

const urls = [] //add all store vids here for which the script needs to be run

describe('value update', function() {

  urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
  
 })

  it(`Common js update on ${url}`, function()
  {

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://mybrandmall.com/preview/listvendors.admin')
      .get('[placeholder="Admin Username"]').type('')             //enter username
      .get('[placeholder="Admin Password"]').type('{enter}').wait(900)   //enter password before curly brace
      .get('[name="quick_search_box"]').type(url)
      .get('[value="Search"]').eq(0).click()
    cy.contains(url).invoke('removeAttr', 'target').click().wait(900)
      .get(':nth-child(5) > .mm-next').click()
    cy.contains('Manage Templates').click().wait(900)
      .get('.expand').click()
      .get('#searchfilename').type('header.vm')
      .get('.col-md-12 > .form-actions > .btn-primary').click()
      .get(':nth-child(3) > #templatenickname0').should('have.text' , 'header')
      .get(':nth-child(3) > :nth-child(6) > a').click().wait(900)
      .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{ctrl}{end}').type('{enter}')
      .type('#set($SessionCustomerDTO_vid="SessionCustomerDTO_"+$vid)').type('{enter}')
      .get('[name="ok"]').click().wait(900)


    cy.get('.fa-sign-out').eq(0).click().wait(300)
   
  
  })
 })
})




  //.get('.ace_meta.ace_tag.ace_name').invoke('attr', 'pointer-events' ,'auto').invoke('attr', 'tabindex', '-1')
      //.get('.ace_layer.ace_marker-layer').invoke('attr', 'pointer-events' ,'auto').invoke('attr', 'tabindex', '-1')
      //.get('.ace_meta.ace_tag.ace_name').contains('body').click({force: true , position: 'topLeft' })
      
      
      //.get('.ace_layer.ace_text-layer').invoke('attr', 'pointer-events' ,'auto')
      //.get('.ace_line').invoke('attr', 'pointer-events' ,'auto').invoke('attr', 'tabindex', '-1')
      //.get('.ace_layer.ace_text-layer > div:nth-child(11)').invoke('attr', 'pointer-events','auto').invoke('attr', 'tabindex', '-1').type('', {force: true})
      
              
      //.get('.ace_search_form > .ace_search_field').type('')
      //.get('.ace_replace_form > .ace_search_field').type('')
