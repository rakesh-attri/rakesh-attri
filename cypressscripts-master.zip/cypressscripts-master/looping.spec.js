

describe('Title Validation', () => {
 var urls = ['https://cb.mypromomall.com/preview/channingbete/health-care/healthy-living' ,'https://cb.mypromomall.com/preview/channingbete/health-care/disease-management']
var cals = ['Healthy Living | Channing Bete' ,'Disease Management | Channing Bete']

  
    it(`Title on `, () => {
    	var i ;
for (i = 0; i < urls.length ; i++) {  
      cy.viewport(1920, 937)
      cy.visit(urls[i]).wait(900)
        
        // cy.xpath('//*[@id="page"]/div/div/div[2]/aside[2]/div[2]/div[1]/div[3]/a')
        // cy.screenshot(i)
        cy.title().should('equal', cals[i])

  }    

    })
  
    })



