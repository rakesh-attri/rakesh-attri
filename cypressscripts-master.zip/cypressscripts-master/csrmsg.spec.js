const urls = []
describe('Template edit', function() {
  urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
  
 })
  it(`PlaceOrderMail update on ${url}`, function()
  {

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://mypromomall.com/preview/listvendors.admin')
      .get('[placeholder="Admin Username"]').type('')             //enter the username
      .get('[placeholder="Admin Password"]').type('{enter}').wait(900)      //enter the password before {enter}
      .get('[name="quick_search_box"]').type(url)
      .get('[value="Search"]').eq(0).click()
    cy.contains(url).invoke('removeAttr', 'target').click().wait(900)
      .get(':nth-child(5) > .mm-next').click()
    cy.contains('Manage Templates').click().wait(900)
      .get('.expand').click()
      .get('#searchfilename').type('PlaceOrderMail.vm')
      .get('.col-md-12 > .form-actions > .btn-primary').click()
      .get(':nth-child(3) > :nth-child(6) > a').click().wait(900)

      // .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{ctrl}H').wait(600)
      // .get('.ace_search_form > .ace_search_field').type('giftCard.msg')
      // .get('.ace_active-line').invoke('attr', 'pointer-events' ,'auto').invoke('attr', 'tabindex', '-1').type('{downarrow}', {force: true})
      // .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{downarrow}{downarrow}{downarrow}{downarrow}{downarrow}{enter}')
      .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto')
      .type('{ctrl}{end}').type('{uparrow}').type('{ctrl}{leftarrow}').type('{ctrl}{leftarrow}').type('{ctrl}{leftarrow}')
      .type('{uparrow}').type('{uparrow}').type('{enter}')

      .type('<tr><td style="font-size: 15px; color: #29303f; font-family: arial; font-weight: normal; line-height: 24px;"><b>HALO remains committed to providing timely and reliable service. However, the COVID-19 pandemic has resulted in an unprecedented demand on carriers and is causing shipping and delivery challenges. Many carriers, including UPS and FedEx, have suspended service guarantees for all shipments from any origin to any destination. Please allow extra time for your merchandise delivery. ')
      
      .get('[name="ok"]').click().wait(900)
    cy.get('.fa-sign-out').eq(0).click().wait(300)
  })
    

   })
   })
