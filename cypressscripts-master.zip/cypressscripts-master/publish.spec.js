/// <reference types="Cypress" />

const urls = ['20200630880' , '20200402544']

describe('Check publish status', function() {
  urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
})

    it(`Check publish status on  ${url}`, () => {
      cy.viewport('macbook-15')
      cy.visit('https://mypromomall.com/preview/listvendors.admin').wait(900)
      .get('[placeholder="Admin Username"]').type('')
      .get('[placeholder="Admin Password"]').type('{enter}').wait(900)
      .get('[name="quick_search_box"]').type(url)
      .get('[value="Search"]').eq(0).click()
    cy.contains(url).invoke('removeAttr', 'target').click().wait(900)
      .get(':nth-child(3) > .mm-next').click()
      .get('.sub-menu').contains('Publish to Shop').click().wait(300)
      .get('[value="Publish / Publish Status"]').click().wait(300)


       	  		 cy.get('tbody > tr > :nth-child(7)').then(($btn) => {
     if ($btn.text().includes('Success')) {
      		
      	cy.writeFile('cypress.txt', url+ ' Published \r\n' , {flag: "a+"})
     } 
     
     else if ($btn.text().includes('Not Done')) {
      	
        cy.writeFile('cypress.txt', url+ ' Queued \r\n' , {flag: "a+"})
    }

    else {

        cy.writeFile('cypress.txt', url+ ' Publish failed \r\n' , {flag: "a+"})
    }
})
        cy.get('.fa-sign-out').eq(0).click().wait(300)
    })
   })
 })