
var i = 0;
for (i = 0; i < 50 ; i++) {  
      
describe('AutoRegister'+i, function() {
  
  var email = this;
  it('User Registration', function()
  {
    cy.viewport('macbook-15')
    // cy.clearCookies()
    cy.visit('https://loadtest001.mypromomall.com/store.html?vid=20170512154')
    //   .get('#welcome-data').click().wait(300)
    //   .url().should('contain', 'signin.html')
    //   .get('#create-new-account').click().wait(300)
    //   .url().should('contain', 'register.html')
    //   .get('[name="customerDTO.firstName"]').type('Automation')
    //   .get('[name="customerDTO.lastName"]').type('Test')
    //   .get('[name="customerDTO.loginname"]').type(email.title).type('')
    //   .get('[name="confirmLogin"]').type(email.title).type('')
    //   .get('[name="customerDTO.loginpassword"]').type('')
    //   .get('[name="confirmPassword"]').type('')
    //   .get('[value="Continue"]').click().wait(900)
    //   .url().should('contain', 'store.html')
    // cy.contains('Automation')
    
  })
})
}