/// <reference types="Cypress" />

describe('OT request create TTB', function() {

  var i = 0;
for (i = 0; i < 10 ; i++) {  

  it('OT request ' , function()
  {
    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('http://192.168.0.171:30071/login?slug=dushyant70')
      .get('#email').type('')
      .get('#password').type('')
      .get('[type="submit"]').click()
      .get('[data-bind="onlinetutoring"]').click()
      .get('#subject_id').click()

                  
                  let math = Math.floor(Math.random() * 10) + 0;
                  console.log(math)  
                
                  

      cy.get('#subject_id-option-'+math).click()
      //   .get('#school_standard').click()
      // cy.get('[role="option"]').eq(math).click()
        .get('#description').type('auto session')
      cy.contains('Next').click()
      cy.get('#duration').click()
        .get('[data-value="60"]').click()
      cy.contains('Next').click()
      cy.get('.MuiInputAdornment-root > .MuiButtonBase-root').click()
        .get(':nth-child(4) > :nth-child(6) > .MuiButtonBase-root > .MuiIconButton-label').click()
        .get('.MuiDialogActions-root > :nth-child(2) > .MuiButton-label').click()
      cy.contains('Next').click()
      cy.get('.MuiButton-containedPrimary').click()
        .get('.jss159').click()
        .get('[data-bind="logout"]').click()
      cy.contains('confirm').click()
  })
}
})