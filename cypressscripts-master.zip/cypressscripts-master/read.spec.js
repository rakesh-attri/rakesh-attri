/// <reference types="Cypress" />

const pwds = 'test1234'

describe('Test', function() {

  before(function () {
    cy.fixture('New').then(function (data) {
      this.laal = data
      console.log(this.laal)
    })
   
  })
 
    it('User Registration using file', function() 
    {
      cy.viewport('macbook-15')


      var i ;
    for (i = 0; i < this.laal.length ; i++) {


    cy.visit('https://mypromomall.com/preview/graywear').wait(900)
    .get('#create-new-account').click().wait(300)
    .url().should('contain', 'register.html')
    
      cy.get('[name="customerDTO.firstName"]').type(this.laal[i].id)
      .get('[name="customerDTO.lastName"]').type(this.laal[i].name)
      .get('[name="customerDTO.loginname"]').type(this.laal[i].name)
      .get('#confirmLogin').type(this.laal[i].name)
      .get('[name="customerDTO.loginpassword"]').type(pwds)
      .get('#confirmPassword').type(pwds)
      .get('#location_shopper_group').select('Gray Solutions')
      .get('#job_title').select('Office')
      .get('#new_hire').click()
    }
    })
   })
 

   