const urls = [] //add all store vids here for which the script needs to be run

describe('Template edit', function() {
  urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
  
 })
  it(`Piwik code remove on ${url}`, function()
  {

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://mybrandmall.com/preview/listvendors.admin')
      .get('[placeholder="Admin Username"]').type('')             //enter the username
      .get('[placeholder="Admin Password"]').type('{enter}').wait(900)      //enter the password before {enter}
      .get('[name="quick_search_box"]').type(url)
      .get('[value="Search"]').eq(0).click()
    cy.contains(url).invoke('removeAttr', 'target').click().wait(900)
      .get(':nth-child(5) > .mm-next').click()
    cy.contains('Manage Templates').click().wait(900)
      .get('.expand').click()
      .get('#searchfilename').type('common_js.vm')
      .get('.col-md-12 > .form-actions > .btn-primary').click()
      .get(':nth-child(3) > :nth-child(6) > a').click().wait(900)
      .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{ctrl}H').wait(600)
      .get('.ace_search_form > .ace_search_field').type('#parse("/$vendorSettingsDTO.vendorId/$vendorSettingsDTO.themeId/piwik.vm")')

      .get('.ace_search_form').then(($btn) => {
     if ($btn.hasClass('ace_search_form ace_nomatch')) {
          
        console.log('box red and piwik code not found on '+url)
     } 
     
     else {
      

      cy.get('.ace_replace_form > .ace_search_field').type('## piwik code removed{enter}')
    //cy.visit('https://qa.mypromomall.com/preview/managetemplates.admin?displayType=0&ppg=viewstore.admin&vid='+url)   //comment this line and uncomment the next to click OK for updating template
      .get('[name="ok"]').click().wait(900)
      
      .get('.expand').click()
      .get('#searchfilename').type('basket.vm')
      .get('.col-md-12 > .form-actions > .btn-primary').click()
      .get(':nth-child(3) > #templatenickname0').should('have.text' , 'basket')
      .get(':nth-child(3) > :nth-child(6) > a').click().wait(900)
      .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{ctrl}H').wait(600)
      .get('.ace_search_form > .ace_search_field').type('#parse("/$vendorSettingsDTO.vendorId/$vendorSettingsDTO.themeId/piwik_abandoned.vm")')
      .get('.ace_replace_form > .ace_search_field').type('## piwik code removed{enter}')
    //cy.visit('https://qa.mypromomall.com/preview/managetemplates.admin?displayType=0&ppg=viewstore.admin&vid='+url)   //comment this line and uncomment the next to click OK for updating template
      .get('[name="ok"]').click().wait(900)

      .get('.expand').click()
      .get('#searchfilename').type('checkout_completed.vm')
      .get('.col-md-12 > .form-actions > .btn-primary').click()
      .get(':nth-child(3) > :nth-child(6) > a').click().wait(900)
      .get('.ace_text-input').invoke('attr', 'pointer-events' ,'auto').type('{ctrl}H').wait(600)
      .get('.ace_search_form > .ace_search_field').type('#parse("/$vendorSettingsDTO.vendorId/$vendorSettingsDTO.themeId/piwik_cart.vm")')
      .get('.ace_replace_form > .ace_search_field').type('## piwik code removed{enter}')
      .get('[name="ok"]').click().wait(900)      //uncomment this line to click OK for updating template


    }

  })
    cy.get('.fa-sign-out').eq(0).click().wait(300)

   })
   })
 })