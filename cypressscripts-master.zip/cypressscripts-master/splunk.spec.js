const urls = ['https://www.mylogocloud.com/preview/store.html?vid=20180213730']   //'https://qa.mypromomall.com/preview/splunk/'

describe('Splunk', function() {

            urls.forEach((url) => {
              Cypress.on('uncaught:exception', (err, runnable) => {
            // returning false here prevents Cypress from 
            // failing the test
            return false
          })
              beforeEach(() => {

                 cy.viewport('macbook-15')
                      cy.clearCookies()
                      cy.visit(url)
                        .get('#welcome-data').click().wait(300)
                        .url().should('contain', 'signin.html')
                        .get('.cookieclose').click()
                        .get('[name="login"]').type('')
                        .get('#password').type('')
                        .get('[value="Login"]').click().wait(300)
                        .url().should('contain', 'store.html')
                      cy.contains('Automation')
                        
    
  })
                    it('Apparel > Activewear', function()

                    {               
                                      
                          cy.get('.nav-dropdown-menu.multi-level').eq(0).invoke('show').contains('Activewear').click({force: true})
                            .url().should('contain', '/shop/apparel/activewear')


                                        .get('h4').eq(0).should('have.text' , 'RACINGKIT')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Limited Edition Splunk> Racing Kits').click()
                                        .url().should('contain', 'RACINGKIT')
                                      cy.contains('Limited Edition Splunk> Racing Kits')
                                        .get('h4 > span').should('have.text' , 'RACINGKIT')
                                        .get('.tab-details > div').contains('Limited Edition Splunk> Racing Kits can be purchased directly at https://www.voler.com/Hubs/Team/SplunkRacingTeam/')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0003')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Mens Nike T-Shirt').click()
                                        .url().should('contain', 'SPK0003')
                                      cy.contains('Mens Nike T-Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0003')
                                        .get('.tab-details > div').should('have.text' , 'This shirt is 100% polyester with premium Dri-FIT fabric that wicks sweat away to keep you dry and comfortable. Additional feature includes flat-seam construction to prevent irritation as you move. Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0468')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Unisex Long Sleeve T-Shirt').click()
                                        .url().should('contain', 'SPK0468')
                                      cy.contains('Unisex Long Sleeve T-Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0468')
                                        .get('.tab-details > div').should('have.text' , 'Keep warm and stay stylish with the Adult long sleeve jersey crewneck t-shirt! Crafted from 4.2 oz., pre-shrunk 100% combed ringspun cotton plus 30 singles, this top is sure to last and last becoming an old favorite and essential layering piece for any wardrobe.  Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0518')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Pilipinx Raglan Shirt').click()
                                        //.url().should('contain', 'SPK0518')
                                      cy.contains('Pilipinx Raglan Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0518')
                                        .get('.tab-details > div').should('have.text' , 'This soft classic knit jersey, is made up of 100% ring spun combed cotton. Additional features include: rib knit neck, 3/4 raglan sleeves and covered hem. Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0460')
                                        .get('.item-title > a').eq(4).should('have.text' , 'Pride Raglan Shirt').click()
                                        .url().should('contain', 'SPK0460')
                                      cy.contains('Pride Raglan Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0460')
                                        .get('.tab-details > div').should('have.text' , 'This soft classic knit jersey, is made up of 100% ring spun combed cotton.  Additional features include: rib knit neck, 3/4 raglan sleeves and covered hem.  Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(5).should('have.text' , 'SPK0469')
                                        .get('.item-title > a').eq(5).should('have.text' , 'BEAMs Raglan Shirt').click()
                                        .url().should('contain', 'SPK0469')
                                      cy.contains('BEAMs Raglan Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0469')
                                        .get('.tab-details > div').should('have.text' , 'This soft classic knit jersey, is made up of 100% ring spun combed cotton. Additional features include: rib knit neck, 3/4 raglan sleeves and covered hem. Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(6).should('have.text' , 'SPK0231')
                                        .get('.item-title > a').eq(6).should('have.text' , 'Womens Nike T-Shirt').click()
                                        .url().should('contain', 'SPK0231')
                                      cy.contains('Womens Nike T-Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0231')
                                        .get('.tab-details > div').should('have.text' , 'This shirt is 100% polyester with premium Dri-FIT fabric that wicks sweat away to keep you dry and comfortable. Additional feature includes flat-seam construction to prevent irritation as you move. Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(7).should('have.text' , 'SPK0149')
                                        .get('.item-title > a').eq(7).should('have.text' , 'Mens Nike Loves SF T-Shirt').click()
                                        .url().should('contain', 'SPK0149')
                                      cy.contains('Mens Nike Loves SF T-Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0149')
                                        .get('.tab-details > div').should('have.text' , 'This Legend T-Shirt S/S poly top Dri-FIT fabric is 100% polyester. Splunk logo is screenprinted in the front and California graphic on the back.')
                                      cy.go('back')


                                        .get('h4').eq(8).should('have.text' , 'SPK0228')
                                        .get('.item-title > a').eq(8).should('have.text' , 'Womens Training Jersey').click()
                                        .url().should('contain', 'SPK0228')
                                      cy.contains('Womens Training Jersey')
                                        .get('h4 > span').should('have.text' , 'SPK0228')
                                        .get('.tab-details > div').should('have.text' , 'Castelli Training jersey with Stratus Plus 2-layer fabric. Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(9).should('have.text' , 'SPK0001')
                                        .get('.item-title > a').eq(9).should('have.text' , 'Mens Training Jersey').click()
                                        .url().should('contain', 'SPK0001')
                                      cy.contains('Mens Training Jersey')
                                        .get('h4 > span').should('have.text' , 'SPK0001')
                                        .get('.tab-details > div').should('have.text' , 'Training jersey with stratus plus 2-layer fabric. Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(10).should('have.text' , 'SPK0230')
                                        .get('.item-title > a').eq(10).should('have.text' , 'Womens Team Bibshorts').click()
                                        .url().should('contain', 'SPK0230')
                                      cy.contains('Womens Team Bibshorts')
                                        .get('h4 > span').should('have.text' , 'SPK0230')
                                        .get('.tab-details > div').should('have.text' , 'Casstelli Team Bibshort with Kiss Air seat pad. Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(11).should('have.text' , 'SPK0002')
                                        .get('.item-title > a').eq(11).should('have.text' , 'Mens Team Bibshort').click()
                                        .url().should('contain', 'SPK0002')
                                      cy.contains('Mens Team Bibshort')
                                        .get('h4 > span').should('have.text' , 'SPK0002')
                                        .get('.tab-details > div').should('have.text' , 'Castelli Team Bibshort with Kiss Air seat pad. Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(12).should('have.text' , 'SPK0520')
                                        .get('.item-title > a').eq(12).should('have.text' , 'Splunk Striped Sock').click()
                                        //.url().should('contain', 'SPK0520')
                                      cy.contains('Splunk Striped Sock')
                                        .get('h4 > span').should('have.text' , 'SPK0520')
                                        .get('.tab-details > div').should('have.text' , 'Look smart with minimal compression and maximum comfort. Crafted with spandex to provide you with extra stretch, light weight and temperature regulation. These socks give you unparalleled comfort 365 days a year.\n')
                                      cy.go('back')


                                        .get('h4').eq(13).should('have.text' , 'SPK0450')
                                        .get('.item-title > a').eq(13).should('have.text' , 'Splunk SOCs').click()
                                        .url().should('contain', 'SPK0450')
                                      cy.contains('Splunk SOCs')
                                        .get('h4 > span').should('have.text' , 'SPK0450')
                                        .get('.tab-details > div').should('have.text' , 'Look smart with minimal compression and maximum comfort.  Crafted with spandex to provide you with extra stretch, light weight and temperature regulation.  These socks give you unparalleled comfort 365 days a year.')
                                      cy.go('back')


                                        .get('h4').eq(14).should('have.text' , 'SPK0526')
                                        .get('.item-title > a').eq(14).should('have.text' , '.conf19 Vans Shoes').click()
                                        .url().should('contain', 'SPK0526')
                                      cy.contains('.conf19 Vans Shoes')
                                        .get('h4 > span').should('have.text' , 'SPK0526')
                                        .get('.tab-details > div').should('have.text' , 'The Classic Slip-On has a low profile, slip-on canvas upper with all-over checker print with custom Splunk colors, elastic side accents. .conf19 logo on back. Sizes are listed as Men\'s sizes, see size chart link for women’s conversion.')
                                         .get('[color="red"]').eq(1).should('have.text' , 'Note: Shoes are not returnable/all sales are final.')

  })  
                    it('Apparel > Outerwear', function()

                    {               
                                      
                          cy.get('.nav-dropdown-menu.multi-level').eq(0).invoke('show').contains('Outerwear').click({force: true})
                            .url().should('contain', '/shop/apparel/outerwear')


                                        .get('h4').eq(0).should('have.text' , 'SPK0235')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Womens North Face Vest').click()
                                        .url().should('contain', 'SPK0235')
                                      cy.contains('Womens North Face Vest')
                                        .get('h4 > span').should('have.text' , 'SPK0235')
                                        .get('.tab-details > div').should('have.text' , 'This vest is made of 15D 33 g ThermoBall™ powered by PrimaLoft®100% nylon insulation. Another feature including ThermoBall™ powered by PrimaLoft® baffles, allows this vest to contour to fit your body and maintain core warmth. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0010')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Mens North Face Vest').click()
                                        .url().should('contain', 'SPK0010')
                                      cy.contains('Mens North Face Vest')
                                        .get('h4 > span').should('have.text' , 'SPK0010')
                                        .get('.tab-details > div').should('have.text' , 'This vest is made of 15D 33 g ThermoBall™ powered by PrimaLoft®100% nylon insulation. Another feature including ThermoBall™ powered by PrimaLoft® baffles, allows this vest to contour to fit your body and maintain core warmth. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0540')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Men\'s North Face Soft Shell').click()
                                        //.url().should('contain', 'SPK0540')
                                      cy.contains('Men\'s North Face Soft Shell')
                                        .get('h4 > span').should('have.text' , 'SPK0540')
                                        .get('.tab-details > div').contains('For hiking, biking or commuting, the Tech Stretch Soft Shell Jacket is a weather-protective, breathable layer with four-way stretch for ease of movement. Constructed of 50% recycled polyester, this all-season, double-weave, versatile jacket promotes sustainability.')
                                        .get('.tab-details > div').contains('Reverse-coil center front zipper')
                                        .get('.tab-details > div').contains('Secure-zip right chest pocket')
                                        .get('.tab-details > div').contains('Secure-zip hand pockets')
                                        .get('.tab-details > div').contains('Elastic-bound cuffs for comfort')
                                        .get('.tab-details > div').contains('Drop tail hem')
                                        .get('.tab-details > div').contains('Contrast embroidered The North Face logo on left sleeve and right back shoulder')
                                        .get('.tab-details > div').contains('Tonal WindWall® logo embroidered on left sleeve')
                                        .get('.tab-details > div').contains('Splunk logo embroidered on chest')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0410')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Womens Patagonia Jacket').click()
                                        .url().should('contain', 'SPK0410')
                                      cy.contains('Womens Patagonia Jacket')
                                        .get('h4 > span').should('have.text' , 'SPK0410')
                                        .get('.tab-details > div').should('have.text' , 'Warm, windproof, water-resistant and supercompressible, Nano Puff products are made with 22-denier 100% recycled polyester and insulated with 60-g PrimaLoft® Gold Insulation Eco with 55% post consumer recycled content. While not quite as warm as down, synthetic insulation will keep you warm even when wet.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0409')
                                        .get('.item-title > a').eq(4).should('have.text' , 'Mens Patagonia Jacket').click()
                                        .url().should('contain', 'SPK0409')
                                      cy.contains('Mens Patagonia Jacket')
                                        .get('h4 > span').should('have.text' , 'SPK0409')
                                        .get('.tab-details > div').should('have.text' , 'Warm, windproof, water-resistant and supercompressible, Nano Puff products are made with 22-denier 100% recycled polyester and insulated with 60-g PrimaLoft® Gold Insulation Eco with 55% post consumer recycled content. While not quite as warm as down, synthetic insulation will keep you warm even when wet.')
                                      cy.go('back')


                                        .get('h4').eq(5).should('have.text' , 'SPK0542')
                                        .get('.item-title > a').eq(5).should('have.text' , 'Women\'s North Face Fleece').click()
                                        //.url().should('contain', 'SPK0542')
                                      cy.contains('Women\'s North Face Fleece')
                                        .get('h4 > span').should('have.text' , 'SPK0542')
                                        .get('.tab-details > div').contains('With plush comfort and warmth, this versatile, super soft fleece works just as well in mild conditions as it does as a mid-layer in colder climates. Features include a stand-up collar and zippered pockets.')
                                        .get('.tab-details > div').contains('260 g/m2 100% polyester kn')
                                        .get('.tab-details > div').contains('Stretch binding at cuffs, pockets and hem')
                                        .get('.tab-details > div').contains('Embroidered The North Face logo on left sleeve and right back shoulder')
                                        .get('.tab-details > div').contains('Splunk logo embroidered on chest')
                                      cy.go('back')


                                        .get('h4').eq(6).should('have.text' , 'SPK0234')
                                        .get('.item-title > a').eq(6).should('have.text' , 'Womens North Face Jacket').click()
                                        .url().should('contain', 'SPK0234')
                                      cy.contains('Womens North Face Jacket')
                                        .get('h4 > span').should('have.text' , 'SPK0234')
                                        .get('.tab-details > div').should('have.text' , 'The perfect layer for spring skiing and early season hikes, this versatile, smooth-faced fleece features a quarter-length zipper that lets you easily regulate temperature.\n\n235 g/m2 100% polyester fleece with soft-brushed interior\nHardwearing design with pill-resistance\nCadet collar\nReverse-coil quarter zipper for easy venting\nDries quickly to minimize heat loss\nContrast embroidered "The North Face" logo on left sleeve\n\nBENEFITS\nBREATHABLE: Mid-weight fabrics that help regulate body temperature.\nSTRETCH: This product contains material with stretch that allows for greater range of mobility. \nSplunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(7).should('have.text' , 'SPK0009')
                                        .get('.item-title > a').eq(7).should('have.text' , 'Mens North Face Jacket').click()
                                        .url().should('contain', 'SPK0009')
                                      cy.contains('Mens North Face Jacket')
                                        .get('h4 > span').should('have.text' , 'SPK0009')
                                        .get('.tab-details > div').should('have.text' , 'The perfect layer for spring skiing and early season hikes, this versatile, smooth-faced fleece features a quarter-length zipper that lets you easily regulate temperature.\n\n235 g/m2 100% polyester fleece with soft-brushed interior\nHardwearing design with pill-resistance\nCadet collar\nReverse-coil quarter zipper for easy venting\nDries quickly to minimize heat loss\nContrast embroidered "The North Face" logo on left sleeve\n\nBENEFITS\nBREATHABLE: Mid-weight fabrics that help regulate body temperature.\nSTRETCH: This product contains material with stretch that allows for greater range of mobility. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(8).should('have.text' , 'SPK0233')
                                        .get('.item-title > a').eq(8).should('have.text' , 'Womens Soft Shell Jacket').click()
                                        .url().should('contain', 'SPK0233')
                                      cy.contains('Womens Soft Shell Jacket')
                                        .get('h4 > span').should('have.text' , 'SPK0233')
                                        .get('.tab-details > div').should('have.text' , 'This jacket is wind and water resistant, constructed from a polyester stretch woven shell with four-way stretch that\'s perfect for corporate or weekend wear. Splunk logo is embroidered.')
    
  })  
                    it('Apparel > Kids', function()

                    {               
                                      
                          cy.get('.nav-dropdown-menu.multi-level').eq(0).invoke('show').contains('Kids').click({force: true})
                            .url().should('contain', '/shop/apparel/kids')


                                        .get('h4').eq(0).should('have.text' , 'SPK0239')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Youth Trouble T-Shirts').click()
                                        .url().should('contain', 'SPK0239')
                                      cy.contains('Youth Trouble T-Shirts')
                                        .get('h4 > span').should('have.text' , 'SPK0239')
                                        .get('.tab-details > div').should('have.text' , 'Unisex youth size tee with tagline " Looking for trouble." Splunk logo on back. 100% Airlume combed and ring-spun cotton, 30 single 4.2 oz')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0411')
                                        .get('.item-title > a').eq(1).should('have.text' , 'New Kid on the Blockchain Onesie').click()
                                        .url().should('contain', 'SPK0411')
                                      cy.contains('New Kid on the Blockchain Onesie')
                                        .get('h4 > span').should('have.text' , 'SPK0411')
                                        .get('.tab-details > div').should('have.text' , 'This onesie is constructed of 100% baby rib cotton. This unisex onesie will shrink an average of one size when put in the dryer and is not intended for sleepwear. It has the Tagline "New kid on the blockchain." on the front.')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0276')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Take the SH Out of Me Onesie').click()
                                        .url().should('contain', 'SPK0276')
                                      cy.contains('Take the SH Out of Me Onesie')
                                        .get('h4 > span').should('have.text' , 'SPK0276')
                                        .get('.tab-details > div').should('have.text' , 'This onesie is constructed of 100% baby rib cotton. This unisex onesie will shrink an average of one size when put in the dryer and is not intended for sleepwear. It has the Tagline "Take the SH out of me." on the front, Splunk logo is screenprinted on the back.')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0370')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Admin Changeme Onesie').click()
                                        .url().should('contain', 'SPK0370')
                                      cy.contains('Admin Changeme Onesie')
                                        .get('h4 > span').should('have.text' , 'SPK0370')
                                        .get('.tab-details > div').should('have.text' , 'This onesie is constructed of 100% baby rib cotton. This unisex onesie will shrink an average of one size when put in the dryer and is not intended for sleepwear. It has the Tagline "Admin Changeme." on the front, Splunk logo is screenprinted on the back.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0238')
                                        .get('.item-title > a').eq(4).should('have.text' , 'Youth Ninja T-Shirt').click()
                                        .url().should('contain', 'SPK0238')
                                      cy.contains('Youth Ninja T-Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0238')
                                        .get('.tab-details > div').should('have.text' , 'Unisex youth size tee with tagline "Because ninjas are too busy." Splunk logo on back. 100% Airlume combed and ring-spun cotton, 30 single 4.2 ozThis slogan is being retired and will not be restocked.')

    
  })          

                   it('Apparel > Pets', function()

                    {               
                                      
                          cy.get('.nav-dropdown-menu.multi-level').eq(0).invoke('show').contains('Pets').click({force: true})
                            .url().should('contain', '/shop/apparel/pets')


                                        .get('h4').eq(0).should('have.text' , 'SPK0236')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Splunk Cat Shirt').click()
                                        .url().should('contain', 'SPK0236')
                                      cy.contains('Splunk Cat Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0236')
                                        .get('.tab-details > div').contains('This shirt is five ounces and is made of 100% combed ring spun cotton. It has as the tagline "Here, data-data-data..." Splunk logo is screenprinted.')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0237')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Splunk Dog Shirt').click()
                                        .url().should('contain', 'SPK0237')
                                      cy.contains('Splunk Dog Shirt')
                                        .get('h4 > span').should('have.text' , 'SPK0237')
                                        .get('.tab-details > div').contains('This shirt is five ounces and is made of 100% combed ring spunk cotton. It has the tagline "Who let the logs out?" Splunk logo is screenprinted.')

    
  })
                   it('Apparel > Hats', function()

                    {               
                                      
                          cy.get('.nav-dropdown-menu.multi-level').eq(0).invoke('show').contains('Hats').click({force: true})
                            .url().should('contain', '/shop/apparel/hats')


                                        .get('h4').eq(0).should('have.text' , 'SPK0475')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Pom Pom Beanie').click()
                                        .url().should('contain', 'SPK0475')
                                      cy.contains('Pom Pom Beanie')
                                        .get('h4 > span').should('have.text' , 'SPK0475')
                                        .get('.tab-details > div').should('have.text' ,'The Pom-Pom Beanie is 100% acrylic. Features a large pom-pom, long cuff, and is super soft with thick knit.')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0476')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Vintage Knit Beanie').click()
                                        .url().should('contain', 'SPK0476')
                                      cy.contains('Vintage Knit Beanie')
                                        .get('h4 > span').should('have.text' , 'SPK0476')
                                        .get('.tab-details > div').should('have.text' ,'The Vintage Knit Beanie is 100% acrylic, and features: a stretch fit, rolled cuff, and a soft and warm knit construction. ')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0061')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Flexfit Delta Hat').click()
                                        .url().should('contain', 'SPK0061')
                                      cy.contains('Flexfit Delta Hat')
                                        .get('h4 > span').should('have.text' , 'SPK0061')
                                        .get('.tab-details > div').should('have.text' ,'This hat features antibacterial, quick drying, and stain-resistant fabric. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0404')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Youth New Era Cap').click()
                                        .url().should('contain', 'SPK0404')
                                      cy.contains('Youth New Era Cap')
                                        .get('h4 > span').should('have.text' , 'SPK0404')
                                        .get('.tab-details > div').should('have.text' ,'New Era\'s exclusive moisture-wicking fabric and renowned fit in a trend-right flat bill.  This hat is 100% polyester Diamond Era jacquard.  Additional features include: structured, profile high and a 7-position adjustable snap.  Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0062')
                                        .get('.item-title > a').eq(4).should('have.text' , 'New Era Hat').click()
                                        .url().should('contain', 'SPK0062')
                                      cy.contains('New Era Hat')
                                        .get('h4 > span').should('have.text' , 'SPK0062')
                                        .get('.tab-details > div').should('have.text' ,'Finding a comfortable fit is easy with the New Era stretch to fit breathable cotton. This hat is 97% cotton and 3% spandex. Additional features include: structure, profile mid, and closure stretch fit. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(5).should('have.text' , 'SPK0020')
                                        .get('.item-title > a').eq(5).should('have.text' , 'All-Black Trucker Hat').click()
                                        .url().should('contain', 'SPK0020')
                                      cy.contains('All-Black Trucker Hat')
                                        .get('h4 > span').should('have.text' , 'SPK0020')
                                        .get('.tab-details > div').should('have.text' ,'This Mesh Cap is a 6-panel relaxed fit baseball cap made of 100% cotton. It features an integrated cotton sweatband, snapback closure, and pre-curved bill. Splunk logo is embroidered.')
                                      cy.go('back')


                                        .get('h4').eq(6).should('have.text' , 'SPK0019')
                                        .get('.item-title > a').eq(6).should('have.text' , 'Black/White Trucker Hat').click()
                                        .url().should('contain', 'SPK0019')
                                      cy.contains('Black/White Trucker Hat')
                                        .get('h4 > span').should('have.text' , 'SPK0019')
                                        .get('.tab-details > div').should('have.text' ,'This Mesh Cap is a 6-panel relaxed fit baseball cap made of 100% cotton. It features an integrated cotton sweatband, snapback closure, and pre-curved bill. Splunk logo is embroidered.')
                                      
  })

                  it('Travel', function()

                    {
                     
                          cy.get('.ada_screen_text').contains('Travel').click()
                            .url().should('contain', '/shop/travel')


                                        .get('h4').eq(0).should('have.text' , 'SPK0493')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Snuggie Blanket').click()
                                        .url().should('contain', 'SPK0493')
                                      cy.contains('Snuggie Blanket')
                                        .get('h4 > span').should('have.text' , 'SPK0493')
                                        .get('.tab-details > div').should('have.text' ,'Wearable blanket with sleeves that\’s ideal for keeping you warm and cozy while watching TV, lounging on sofa/bed, gaming, or reading a book.  Size:  70" X 50" and fits most adult men and women.  Care instructions:  Wash separately in cold water, tumble dry low.')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0472')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Travel Quillow').click()
                                        .url().should('contain', 'SPK0472')
                                      cy.contains('Travel Quillow')
                                        .get('h4 > span').should('have.text' , 'SPK0472')
                                        .get('.tab-details > div').contains('Comfortable travel just got easier with this plush, Velura™ pillow that unfolds into the perfect size blanket for any trip. Ideal for in the car, on the plane or just relaxing at home. Includes a zippered front pocket that safely holds eyeglasses, books, musical devices and other accessories.')
                                        .get('.tab-details > div').contains('This super-soft blanket folds up into its own integrated pouch, barely taking up any room in your hand luggage. And the snap feature on the strap allows the pillow to easily attach to the outside of any bag. Dimensions: 36" x 60"/ Folds into pillow 12.5" x 10"')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0393')
                                        .get('.item-title > a').eq(2).should('have.text' , 'RuMe Garment Travel Organizer').click()
                                        .url().should('contain', 'SPK0393')
                                      cy.contains('RuMe Garment Travel Organizer')
                                        .get('h4 > span').should('have.text' , 'SPK0393')
                                        .get('.tab-details > div').should('have.text' ,'Includes multiple packing cubes, and is designed to fit snugly when full, into standard rolling suitcase. Secures with two adjustable buckles.')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0387')
                                        .get('.item-title > a').eq(3).should('have.text' , 'American Tourister Amenity  Case').click()
                                        .url().should('contain', 'SPK0387')
                                      cy.contains('American Tourister Amenity Case')
                                        .get('h4 > span').should('have.text' , 'SPK0387')
                                        .get('.tab-details > div').should('have.text' ,'American Tourister Voyager Amenity Case with zippered main compartment. Expandable sides for extra packing capacity. Built-in hooks allowing you to hang it, top grab handle.')
  }) 

                     it('Drinkware', function()

                    {               

                          cy.get('.ada_screen_text').contains('Drinkware').click()
                            .url().should('contain', '/shop/drinkware')

                                        .get('h4').eq(0).should('have.text' , 'SPK0055')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Can Koozie').click()
                                        .url().should('contain', 'SPK0055')
                                      cy.contains('Can Koozie')
                                        .get('h4 > span').should('have.text' , 'SPK0055')
                                        .get('.tab-details > div').should('have.text' ,'Slogan "Get to the bottom of IT" is shown on the back of the koozie. Dimensions: 3 7/8" W x 5 1/4" H. Splunk logo is screen printed.')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0535')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Ceramic Mug').click()
                                        //.url().should('contain', 'SPK0535')
                                      cy.contains('Ceramic Mug')
                                        .get('h4 > span').should('have.text' , 'SPK0535')
                                        .get('.tab-details > div').contains('This 12 oz stoneware mug features a matte black exterior with a glossy finish interior.')
                                        .get('.tab-details > div').contains('Hand wash recommended')
                                        .get('.tab-details > div').contains('Microwave safe')
                                        .get('.tab-details > div').contains('Dimensions: 4-5/8" H x 3-3/8" (4-3/4" w/handle) W')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0282')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Bolzano Mug').click()
                                        .url().should('contain', 'SPK0282')
                                      cy.contains('Bolzano Mug')
                                        .get('h4 > span').should('have.text' , 'SPK0282')
                                        .get('.tab-details > div').should('have.text' , '18 oz. Stoneware C-Handle Bolzano Mug is matte black on the outside and glossy color inside. Handwash recommended. Microwave safe with non-metallic imprint. Splunk logo is screen printed. ')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0013')
                                        .get('.item-title > a').eq(3).should('have.text' , 'CamelBak Water Bottle').click()
                                        .url().should('contain', 'SPK0013')
                                      cy.contains('CamelBak Water Bottle')
                                        .get('h4 > span').should('have.text' , 'SPK0013')
                                        .get('.tab-details > div').should('have.text' ,'Durable Tritan™ material.   Shatter, stain, and odor resistant.   Enjoy spill-proof sipping at work or on the trail with the eddy®+ water bottle.  Screw-on lid with spill-proof bite valve and one-finger carry handle. No tip drinking, simply flip open Bite Valve & Sip.  Wide mouth opening for easy cleaning and filling.  BPA Free, 25oz.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0536')
                                        .get('.item-title > a').eq(4).should('have.text' , 'Canteen 25oz').click()
                                        //.url().should('contain', 'SPK0536')
                                      cy.contains('Canteen 25oz')
                                        .get('h4 > span').should('have.text' , 'SPK0536')
                                        .get('.tab-details > div').contains('The original, colorfully cool Corkcicle 25oz Canteen, keeps drinks ice cold for 25 hours or warm for 12. The drinkware holds an entire bottle of wine and features a screw-on cap.')
                                        .get('.tab-details > div').contains('Triple-layer insulation')
                                        .get('.tab-details > div').contains('Wide mouth easily accommodates standard size ice cubes')
                                        .get('.tab-details > div').contains('Non-Slip Bottom')
                                      cy.go('back')


                                        .get('h4').eq(5).should('have.text' , 'SPK0041')
                                        .get('.item-title > a').eq(5).should('have.text' , 'Steel/Copper Water Bottle').click()
                                        .url().should('contain', 'SPK0041')
                                      cy.contains('Steel/Copper Water Bottle')
                                        .get('h4 > span').should('have.text' , 'SPK0041')
                                        .get('.tab-details > div').contains('Bottle is double wall 18/8 grade stainless steel with vacuum insulation. The inner wall is plated with copper for ultimate conductivity to keep beverages hot or cold for 8 to 16 hours.')
                                        .get('.tab-details > div').contains('Holds 17 ounces. Dimensions: 10.25" H. Splunk logo is pad printed')
                                      cy.go('back')


                                        .get('h4').eq(6).should('have.text' , 'SPK0413')
                                        .get('.item-title > a').eq(6).should('have.text' , 'h2go Silo').click()
                                        .url().should('contain', 'SPK0413')
                                      cy.contains('h2go Silo')
                                        .get('h4 > span').should('have.text' , 'SPK0413')
                                        .get('.tab-details > div').should('have.text' ,'This 16.9 oz double wall 18/8 stainless steel thermal tumbler comes with copper vacuum insulation, threaded insulated lid, and powder coated finish. 12 hours hot. 24 hours cold. Hand wash recommended.  Do not microwave. 10 1/2" h x 2 1/4" w 500 ml.')
                                      cy.go('back')


                                        .get('h4').eq(7).should('have.text' , 'SPK0414')
                                        .get('.item-title > a').eq(7).should('have.text' , 'h2go Venture').click()
                                        .url().should('contain', 'SPK0414')
                                      cy.contains('h2go Venture')
                                        .get('h4 > span').should('have.text' , 'SPK0414')
                                        .get('.tab-details > div').should('have.text' ,'This 40 oz double wall powder coated 18/8 stainless steel thermal bottle comes with copper vacuum insulation, threaded insulated lid, silicone band, and lid retaining loop.  12 hours hot.  24 hours cold.  Hand wash recommended.  Do not microwave.  11-1/4 h x 3-1/2 (w/o loop) w.  1183mL .')
                                      cy.go('back')


                                        .get('h4').eq(8).should('have.text' , 'SPK0412')
                                        .get('.item-title > a').eq(8).should('have.text' , 'Contigo Tumbler').click()
                                        .url().should('contain', 'SPK0412')
                                      cy.contains('Contigo Tumbler')
                                        .get('h4 > span').should('have.text' , 'SPK0412')
                                        .get('.tab-details > div').should('have.text' ,'This 16 oz double wall stainless steel tumbler comes with vacuum insulation, easy-clean threaded lid with locking mechanism and patented AUTOSEAL push-button.  6 hours hot. 12 hours cold.  Hand wash recommended.  Do not microwave; 7-7/8 h x 3-1/2 w 473mL.')
                                      cy.go('back')


                                        .get('h4').eq(9).should('have.text' , 'SPK0022')
                                        .get('.item-title > a').eq(9).should('have.text' , 'Contigo Bottle').click()
                                        .url().should('contain', 'SPK0022')
                                      cy.contains('Contigo Bottle')
                                        .get('h4 > span').should('have.text' , 'SPK0022')
                                        .get('.tab-details > div').should('have.text' ,'This 20 oz. double wall stainless steel bottle features vacuum insulation, auto spout threaded lid, silicone spout, spout shield, one-touch push-button, and carrying handle. Hand wash recommended. Do not microwave. Splunk logo is spot color.')
                                      cy.go('back')


                                        .get('h4').eq(10).should('have.text' , 'SPK0403')
                                        .get('.item-title > a').eq(10).should('have.text' , 'Martini Set').click()
                                        .url().should('contain', 'SPK0403')
                                      cy.contains('Martini Set')
                                        .get('h4 > span').should('have.text' , 'SPK0403')
                                        .get('.tab-details > div').should('have.text' ,'Beautiful combination of Stainless Steel Shaker & Glasses Packaged in a beautiful Satin Lined box.  Logo (on the glasses) is engraved on the back of the glass to be read when looking through the glass.')
                                      cy.go('back')


                                        .get('h4').eq(11).should('have.text' , 'SPK0452')
                                        .get('.item-title > a').eq(11).should('have.text' , 'Metal Forever Straw').click()
                                        .url().should('contain', 'SPK0452')
                                      cy.contains('Metal Forever Straw')
                                        .get('h4 > span').should('have.text' , 'SPK0452')
                                        .get('.tab-details > div').should('have.text' ,'A great reusable straw designed to collapse into a palm-sized travel case. Durable Stainless Steel and Medical Grade Silicone makes this product very durable and Food Safe. The compact folding design allows the full-size straw to fit inside a palm-sized travel case and cleanup is simple using the provided squeegee.')
  }) 

                     it('Outdoor', function()

                    {               
                                      

                          cy.get('.ada_screen_text').contains('Outdoor').click()
                            .url().should('contain', '/shop/outdoor')


                                        .get('h4').eq(0).should('have.text' , 'SPK0537')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Picnic Blanket').click()
                                        //.url().should('contain', 'SPK0537')
                                      cy.contains('Picnic Blanket')
                                        .get('h4 > span').should('have.text' , 'SPK0537')
                                        .get('.tab-details > div').contains('Designed for outdoor events, this packable blanket has a water-resistant woven backing and a soft fleece face. It can be used as a comfortable seating pad or unzipped and laid out as a picnic blanket.')
                                        .get('.tab-details > div').contains('11 oz, 100% polyester fleece, 100% polyester woven backing')
                                        .get('.tab-details > div').contains('Zips around itself for easy folding')
                                        .get('.tab-details > div').contains('Folding instructions hangtag')
                                        .get('.tab-details > div').contains('Front patch pocket for easy decoration access with hook and loop closure')
                                        .get('.tab-details > div').contains('Over-the-shoulder length web carrying strap')
                                        .get('.tab-details > div').contains('Dimensions: 57" x 50" (unfolded)')
                                      cy.go('back')


                                        .get('h4').eq(1).should('have.text' , 'SPK0500')
                                        .get('.item-title > a').eq(1).should('have.text' , 'Sunscreen Combo').click()
                                        .url().should('contain', 'SPK0500')
                                      cy.contains('Sunscreen Combo')
                                        .get('h4 > span').should('have.text' , 'SPK0500')
                                        .get('.tab-details > div').should('have.text' , 'Perfect for clipping to your jeans or backpack, this dynamic, travel-friendly duo includes broad-spectrum SPF 30 coconut sunscreen and SPF 15 coconut lip balm. Both are free of oxybenzone, PABA and gluten. ')
                                      cy.go('back')


                                        .get('h4').eq(2).should('have.text' , 'SPK0477')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Basketball').click()
                                        .url().should('contain', 'SPK0477')
                                      cy.contains('Basketball')
                                        .get('h4 > span').should('have.text' , 'SPK0477')
                                        .get('.tab-details > div').should('have.text' , 'Mini rubber basketball 7" diameter is extra durable and features a re-inflatable athletic valve.')
                                      cy.go('back')


                                        .get('h4').eq(3).should('have.text' , 'SPK0478')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Football').click()
                                        .url().should('contain', 'SPK0478')
                                      cy.contains('Football')
                                        .get('h4 > span').should('have.text' , 'SPK0478')
                                        .get('.tab-details > div').should('have.text' , 'Foam 10" football is soft and durable.')
                                      cy.go('back')


                                        .get('h4').eq(4).should('have.text' , 'SPK0392')
                                        .get('.item-title > a').eq(4).should('have.text' , 'Picnic Backpack').click()
                                        .url().should('contain', 'SPK0392')
                                      cy.contains('Picnic Backpack')
                                        .get('h4 > span').should('have.text' , 'SPK0392')
                                        .get('.tab-details > div').should('have.text' , 'Fully equipped four person picnic backpack with detachable wine holder & Thermal Shield" insulated cooler compartment to keep food and drink at perfect temperature. Includes combination corkscrew, hardwood cutting board, cheese knife, wooden salt & pepper shakers with non spill tops, and much more!')
                                      cy.go('back')


                                        .get('h4').eq(5).should('have.text' , 'SPK0408')
                                        .get('.item-title > a').eq(5).should('have.text' , 'Sunglasses').click()
                                        .url().should('contain', 'SPK0408')
                                      cy.contains('Sunglasses')
                                        .get('h4 > span').should('have.text' , 'SPK0408')
                                        .get('.tab-details > div').should('have.text' , 'Inspired by the 50’s, our new, signature style, clubman sunglasses, are reinventing promotional sunglasses.')
                                      cy.go('back')


                                        .get('h4').eq(6).should('have.text' , 'SPK0364')
                                        .get('.item-title > a').eq(6).should('have.text' , 'License Plate Frame').click()
                                        .url().should('contain', 'SPK0364')
                                      cy.contains('License Plate Frame')
                                        .get('h4 > span').should('have.text' , 'SPK0364')
                                        .get('.tab-details > div').should('have.text' , 'Splunk license plate. ')
                                      cy.go('back')


                                        .get('h4').eq(7).should('have.text' , 'SPK0063')
                                        .get('.item-title > a').eq(7).should('have.text' , 'Walk Safe Umbrella').click()
                                        .url().should('contain', 'SPK0063')
                                      cy.contains('Walk Safe Umbrella')
                                        .get('h4 > span').should('have.text' , 'SPK0063')
                                        .get('.tab-details > div').should('have.text' , ' Opening and closing automatically at the push of a button, the 47-inch canopy arc collapses in reverse to keep the rain off you, away from your stuff and out of your car. Featuring a black electrostatic steel shaft and ribs paired with FRP fiberglass for strength, the rubber-coated handle has a matching button to the canopy color. Includes a self fabric travel case.  Umbrella is 12.5" in length. Splunk logo is silkscreen.')
                                      cy.go('back')


                                        .get('h4').eq(8).should('have.text' , 'SPK0394')
                                        .get('.item-title > a').eq(8).should('have.text' , 'Wall Mount Bottle Opener').click()
                                        .url().should('contain', 'SPK0394')
                                      cy.contains('Wall Mount Bottle Opener')
                                        .get('h4 > span').should('have.text' , 'SPK0394')
                                        .get('.tab-details > div').should('have.text' , 'Made from beechwood and includes felt backing to protect surface. Powerful magnets catch the cap before it drops.')
                                      cy.go('back')


                                        .get('h4').eq(9).should('have.text' , 'SPK0395')
                                        .get('.item-title > a').eq(9).should('have.text' , 'Igloo Cooler').click()
                                        .url().should('contain', 'SPK0395')
                                      cy.contains('Igloo Cooler')
                                        .get('h4 > span').should('have.text' , 'SPK0395')
                                        .get('.tab-details > div').should('have.text' , 'Cooler collapses and secures with hook and loop fasteners for easy storing. Enhanced insulation with antimicrobial lining with 24 can capacity. Dimensions: 11.5"L 10.5"H 8.5"W')
                                      cy.go('back')


                                        .get('h4').eq(10).should('have.text' , 'SPK0016')
                                        .get('.item-title > a').eq(10).should('have.text' , 'Splunk Flag').click()
                                        .url().should('contain', 'SPK0016')
                                      cy.contains('Splunk Flag')
                                        .get('h4 > span').should('have.text' , 'SPK0016')
                                        .get('.tab-details > div').should('have.text' , 'This flag is made of mesh polyester and features 2 grommets on the left side. Dimensions: 3\' H x 5\' L. Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(11).should('have.text' , 'SPK0391')
                                        .get('.item-title > a').eq(11).should('have.text' , 'BBQ Apron Tote Pro').click()
                                        .url().should('contain', 'SPK0391')
                                      cy.contains('BBQ Apron Tote Pro')
                                        .get('h4 > span').should('have.text' , 'SPK0391')
                                        .get('.tab-details > div').should('have.text' , 'BBQ set with apron, conveniently folds into an easy-to-carry tote with adjustable strap.')
                                      cy.go('back')


                                        .get('h4').eq(12).should('have.text' , 'SPK0060')
                                        .get('.item-title > a').eq(12).should('have.text' , 'Titleist Pro V1 Golf Balls').click()
                                        .url().should('contain', 'SPK0060')
                                      cy.contains('Titleist Pro V1 Golf Balls')
                                        .get('h4 > span').should('have.text' , 'SPK0060')
                                        .get('.tab-details > div').should('have.text' , 'The new Pro V1 provides the exceptional distance and durability golfers have counted on, and now also delivers increased spin control and a more consistent flight. This advanced performance results from a new innovative ZG process core technology, responsive ionomeric casing layer, Urethane Elastomer cover and spherically tiled 352 tetrahedral dimple design. And with 3 axes of symmetry, our new aerodynamics deliver a penetrating ball flight that holds its line in the wind. Comes with 1 dozen golf balls. Splunk logo is pad printed.')
                                      cy.go('back')


                                        .get('h4').eq(13).should('have.text' , 'SPK0069')
                                        .get('.item-title > a').eq(13).should('have.text' , 'Plush Blanket').click()
                                        .url().should('contain', 'SPK0069')
                                      cy.contains('Plush Blanket')
                                        .get('h4 > span').should('have.text' , 'SPK0069')
                                        .get('.tab-details > div').should('have.text' , 'The top side features silken faux micro mink and the inside is a lusciously soft faux sheepskin sherpa layer. This blanket is 100% microfiber polyester fabric and measures 50" x 60". Splunk logo is sublimated.')
                                      cy.go('back')


                                        .get('h4').eq(14).should('have.text' , 'SPK0439')
                                        .get('.item-title > a').eq(14).should('have.text' , 'Leatherman Tool').click()
                                        .url().should('contain', 'SPK0439')
                                      cy.contains('Leatherman Tool')
                                        .get('h4 > span').should('have.text' , 'SPK0439')
                                        .get('.tab-details > div').should('have.text' , 'Durable 12-in-1 Multi-Tool with stainless steel body and replaceable pocket clip. Includes: needle nose pliers, regular pliers, wire cutters, locking 420HC knife, package opener, ruler, can opener, bottle opener, wood/metal file, phillips screwdriver, medium screwdriver and small screwdriver.')
  }) 

                     it('Technology', function()

                    {               
                                      
                          cy.get('.ada_screen_text').contains('Technology').click()
                            .url().should('contain', '/shop/technology')

                                        .get('h4').eq(0).should('have.text' , 'SPK0502')
                                        .get('.item-title > a').eq(0).should('have.text' , 'Air Pockets').click()
                                        .url().should('contain', 'SPK0502')
                                      cy.contains('Air Pockets')
                                        .get('h4 > span').should('have.text' , 'SPK0502')
                                        .get('.tab-details > div').should('have.text' ,'Air Pocket is just another great way to carry your Apple AirPods with you. It is a soft silicone cover that wraps around the original case providing a snug layer of extra protection to your coveted AirPods. The Air Pocket also comes with a small carabiner clip which allows you to clip your case to your bag, your purse, your pants, anywhere you want! There is also a flap at the bottom which provides access to the charging port, as well as a bump on the back so you can still turn the charging function on and off. ')
                                      cy.go('back')

                                        .get('h4').eq(1).should('have.text' , 'SPK0470')
                                        .get('.item-title > a').eq(1).should('have.text' , 'AirCharge Plus').click()
                                        .url().should('contain', 'SPK0470')
                                      cy.contains('AirCharge Plus')
                                        .get('h4 > span').should('have.text' , 'SPK0470')
                                        .get('.tab-details > div').should('have.text' ,'With the AirCharge Plus 5000 mAh Power Bank it will be easier than ever to stay charged. Have a wireless charging phone? Place it on the AirCharge Plus to power up! Still charging using wires? No problem! All major cables are built right in: Lightning Compatible, micro USB, and Type-C. When time to recharge the AirCharge Plus, simply plug it directly into your wall via the integrated AC Plug.')
                                      cy.go('back')

                                        .get('h4').eq(2).should('have.text' , 'SPK0489')
                                        .get('.item-title > a').eq(2).should('have.text' , 'Belkin Charger').click()
                                        .url().should('contain', 'SPK0489')
                                      cy.contains('Belkin Charger')
                                        .get('h4 > span').should('have.text' , 'SPK0489')
                                        .get('.tab-details > div').should('have.text' , '918 Joule energy rating provides superior power protection for all your sensitive mobile devices.  Product is wall-mountable for extra outlets without extra cords.  More features include:  360-degree rotating plug with 4 locking positions, 2 powered USB Ports (2.1 AMP combined), a Surge Protection Indicator that lets you know your equipment is secure and protected, and oversized Metal Oxide Varistors (MOVs) that absorb electricity for increased protection.  The Damage-Resistant Housing protects circuits from fire, impact or rust, and prevents dents and scratches.  This item has a Lifetime Product Warranty.')
                                      cy.go('back')

                                        .get('h4').eq(3).should('have.text' , 'SPK0388')
                                        .get('.item-title > a').eq(3).should('have.text' , 'Bottle Opener with Micro USB Charge').click()
                                        .url().should('contain', 'SPK0388')
                                      cy.contains('Bottle Opener with Micro USB Charge')
                                        .get('h4 > span').should('have.text' , 'SPK0388')
                                        .get('.tab-details > div').should('have.text' , 'Bottle Opener with Micro USB charge and data sync cord.')
                                      cy.go('back')

                                        .get('h4').eq(4).should('have.text' , 'SPK0054')
                                        .get('.item-title > a').eq(4).should('have.text' , '16GB USB Drive').click()
                                        .url().should('contain', 'SPK0054')
                                      cy.contains('16GB USB Drive')
                                        .get('h4 > span').should('have.text' , 'SPK0054')
                                        .get('.tab-details > div').should('have.text' , 'USB has 16GB of storage space. Splunk logo is pad printed.')
                                      cy.go('back')

                                        .get('h4').eq(5).should('have.text' , 'SPK0072')
                                        .get('.item-title > a').eq(5).should('have.text' , 'Wall USB Charger').click()
                                        .url().should('contain', 'SPK0072')
                                      cy.contains('Wall USB Charger')
                                        .get('h4 > span').should('have.text' , 'SPK0072')
                                        .get('.tab-details > div').should('have.text' , 'Dual port 2A USB wall charger. Standard design that charges two devices at once. Splunk logo is pad printed.')
                                      cy.go('back')

                                        .get('h4').eq(6).should('have.text' , 'SPK0492')
                                        .get('.item-title > a').eq(6).should('have.text' , 'Tile Pro').click()
                                        .url().should('contain', 'SPK0492')
                                      cy.contains('Tile Pro')
                                        .get('h4 > span').should('have.text' , 'SPK0492')
                                        .get('.tab-details > div').should('have.text' , 'The NEW Tile Pro is our most powerful Bluetooth tracker for finding all your things. It has a 300 foot range that\'s 2X our NEW Tile Mate. You can relax knowing our replaceable battery runs for a year with no upkeep, and then easily replace it yourself. This durable, water-resistant tracker is also twice as loud, making it easier to find everything.')
                                      cy.go('back')

                                        .get('h4').eq(7).should('have.text' , 'SPK0506')
                                        .get('.item-title > a').eq(7).should('have.text' , 'Qi Stand Wireless Charger').click()
                                        .url().should('contain', 'SPK0506')
                                      cy.contains('Qi Stand Wireless Charger')
                                        .get('h4 > span').should('have.text' , 'SPK0506')
                                        .get('.tab-details > div').should('have.text' , 'Conveniently charge your qi-enabled device on the Qi Stand Wireless Charger.  The collapsible Charger doubles as a phone stand and is easily adjustable for a variety of height options. Constructed of ABS plastic.  Only compatible with qi-enabled devices.')
                                      cy.go('back')

                                        .get('h4').eq(8).should('have.text' , 'SPK0386')
                                        .get('.item-title > a').eq(8).should('have.text' , 'mophie Powerboost').click()
                                        .url().should('contain', 'SPK0386')
                                      cy.contains('mophie Powerboost')
                                        .get('h4 > span').should('have.text' , 'SPK0386')
                                        .get('.tab-details > div').should('have.text' , 'mophie Power Boost Essential 10400 mAh Power Bank.  Portable, rechargeable with dual output USB Ports. Features LED indicators and push button charging.')
                                      cy.go('back')

                                        .get('h4').eq(9).should('have.text' , 'SPK0399')
                                        .get('.item-title > a').eq(9).should('have.text' , 'Charge Stream +').click()
                                        .url().should('contain', 'SPK0399')
                                      cy.contains('Charge Stream +')
                                        .get('h4 > span').should('have.text' , 'SPK0399')
                                        .get('.tab-details > div').should('have.text' , 'The mophie Charge Stream Pad+ delivers up to 10W of power for fast-charging speeds to Qi-enabled smartphones on contact, and optimized for Apple and Samsung Fast Charge. Included cable and wall adapter.')
                                      cy.go('back')

                                        .get('h4').eq(10).should('have.text' , 'SPK0543')
                                        .get('.item-title > a').eq(10).should('have.text' , 'Bluetooth Speaker').click()
                                        //.url().should('contain', 'SPK0543')
                                      cy.contains('Bluetooth Speaker')
                                        .get('h4 > span').should('have.text' , 'SPK0543')
                                        .get('.tab-details > div').contains('From the pool to the park to the patio, the bluetooth speaker is a tough and water-resistant companion that’s perfect for any adventure. Featuring a soft-touch silicone exterior and a built-in microphone for calls, it’s your go-to speaker with bold sound—wherever you need it.')
                                        .get('.tab-details > div').contains('Dimensions: 5.25" H x 5" W x 2.25" D')
                                        .get('.tab-details > div').contains('Weight 1.2 lbs')
                                        .get('.tab-details > div').contains('Wireless Range up to 30 ft')
                                        .get('.tab-details > div').contains('Battery life up to 8 hrs')
                                      cy.go('back')

                                        .get('h4').eq(11).should('have.text' , 'SPK0400')
                                        .get('.item-title > a').eq(11).should('have.text' , 'Bose SoundSport Wireless Headphones').click()
                                        .url().should('contain', 'SPK0400')
                                      cy.contains('Bose SoundSport Wireless Headphones')
                                        .get('h4 > span').should('have.text' , 'SPK0400')
                                        .get('.tab-details > div').should('have.text' , ' Bose SoundSport wireless headphones keep you moving with powerful audio and earbuds that stay secure and comfortable.')
                                      cy.go('back')

                                        .get('h4').eq(12).should('have.text' , 'SPK0389')
                                        .get('.item-title > a').eq(12).should('have.text' , 'Moleskine Smart Writing Set').click()
                                        .url().should('contain', 'SPK0389')
                                      cy.contains('Moleskine Smart Writing Set')
                                        .get('h4 > span').should('have.text' , 'SPK0389')
                                        .get('.tab-details > div').should('have.text' , 'Paper tablet with special paper designed to work with Pen+ in dotted layout, Pen+ smartpen, USB cable for smartpen recharging, 1 pen tip ink refill included, compatible with iOS and Android.')
  }) 

                     it('Gift Certificate', function()

                    {               
                                 

                          cy.get('.ada_screen_text').contains('Gift Certificate').click()
                            .url().should('contain', '/shop/gift-certificate')

                                        .get('h4').eq(0).should('have.text' , 'SPK50-PURCH')
                                        .get('.item-title > a').eq(0).should('have.text' , '$50 Gift Certificate').click()
                                        .url().should('contain', 'SPK50-PURCH')
                                      cy.contains('$50 Gift Certificate')
                                        .get('h4 > span').should('have.text' , 'SPK50-PURCH')
                                        .get('.tab-details > div').contains('Give the gift of Splunk gear! This electronic gift certificate can be used toward the purchase of swag @ Splunk.Shop. Go ahead spend it all in one place!')
                                        .get('.tab-details > div').contains('TO PURCHASE: ADD ONE OR MORE E-CERTIFICATES TO YOUR SHOPPING CART, AND CHECK OUT AS USUAL.')
                                        .get('.tab-details > div').contains('AFTER PAYMENT, PLEASE ALLOW 1 BUSINESS DAY FOR YOUR CERTIFICATE CODE TO BE GENERATED AND EMAILED TO YOU.')
                                        .get('.tab-details > div').contains('TO REDEEM: ENTER THE UNIQUE E-CERTIFICATE CODE IN THE GIFT CERTIFICATE SECTION AT CHECKOUT.')
                                        .get('.tab-details > div').contains('UPON REDEMPTION, THE CREDIT AMOUNT WILL BE APPLIED TO THE SHOPPING CART TOTAL.')
                                        .get('.tab-details > div').contains('GIFT CERTIFICATES HAVE NO EXPIRATION DATE')
                                        .get('[color="red"]').should('have.text' , 'Your official Splunk e-certificate will arrive to you via email in 24 hours and each one will have a unique code to be applied at checkout.')
                                      cy.go('back')

                                        .get('h4').eq(1).should('have.text' , 'SPK75-PURCH')
                                        .get('.item-title > a').eq(1).should('have.text' , '$75 Gift Certificate').click()
                                        .url().should('contain', 'SPK75-PURCH')
                                      cy.contains('$75 Gift Certificate')
                                        .get('h4 > span').should('have.text' , 'SPK75-PURCH')
                                        .get('.tab-details > div').contains('Give the gift of Splunk gear! This electronic gift certificate can be used toward the purchase of swag @ Splunk.Shop. Go ahead spend it all in one place!')
                                        .get('.tab-details > div').contains('TO PURCHASE: ADD ONE OR MORE E-CERTIFICATES TO YOUR SHOPPING CART, AND CHECK OUT AS USUAL.')
                                        .get('.tab-details > div').contains('AFTER PAYMENT, PLEASE ALLOW 1 BUSINESS DAY FOR YOUR CERTIFICATE CODE TO BE GENERATED AND EMAILED TO YOU.')
                                        .get('.tab-details > div').contains('TO REDEEM: ENTER THE UNIQUE E-CERTIFICATE CODE IN THE GIFT CERTIFICATE SECTION AT CHECKOUT.')
                                        .get('.tab-details > div').contains('UPON REDEMPTION, THE CREDIT AMOUNT WILL BE APPLIED TO THE SHOPPING CART TOTAL.')
                                        .get('.tab-details > div').contains('GIFT CERTIFICATES HAVE NO EXPIRATION DATE')
                                        .get('[color="red"]').should('have.text' , 'Your official Splunk e-certificate will arrive to you via email in 24 hours and each one will have a unique code to be applied at checkout.')
                                      cy.go('back')

                                        .get('h4').eq(2).should('have.text' , 'SPK100-PURCH')
                                        .get('.item-title > a').eq(2).should('have.text' , '$100 Gift Certificate').click()
                                        .url().should('contain', 'SPK100-PURCH')
                                      cy.contains('$100 Gift Certificate')
                                        .get('h4 > span').should('have.text' , 'SPK100-PURCH')
                                        .get('.tab-details > div').contains('Give the gift of Splunk gear! This electronic gift certificate can be used toward the purchase of swag @ Splunk.Shop. Go ahead spend it all in one place!')
                                        .get('.tab-details > div').contains('TO PURCHASE: ADD ONE OR MORE E-CERTIFICATES TO YOUR SHOPPING CART, AND CHECK OUT AS USUAL.')
                                        .get('.tab-details > div').contains('AFTER PAYMENT, PLEASE ALLOW 1 BUSINESS DAY FOR YOUR CERTIFICATE CODE TO BE GENERATED AND EMAILED TO YOU.')
                                        .get('.tab-details > div').contains('TO REDEEM: ENTER THE UNIQUE E-CERTIFICATE CODE IN THE GIFT CERTIFICATE SECTION AT CHECKOUT.')
                                        .get('.tab-details > div').contains('UPON REDEMPTION, THE CREDIT AMOUNT WILL BE APPLIED TO THE SHOPPING CART TOTAL.')
                                        .get('.tab-details > div').contains('GIFT CERTIFICATES HAVE NO EXPIRATION DATE')
                                        .get('[color="red"]').should('have.text' , 'Your official Splunk e-certificate will arrive to you via email in 24 hours and each one will have a unique code to be applied at checkout.')
                                      cy.go('back')

                                        .get('h4').eq(3).should('have.text' , 'SPK250-PURCH')
                                        .get('.item-title > a').eq(3).should('have.text' , '$250 Gift Certificate').click()
                                        .url().should('contain', 'SPK250-PURCH')
                                      cy.contains('$250 Gift Certificate')
                                        .get('h4 > span').should('have.text' , 'SPK250-PURCH')
                                        .get('.tab-details > div').contains('Give the gift of Splunk gear! This electronic gift certificate can be used toward the purchase of swag @ Splunk.Shop. Go ahead spend it all in one place!')
                                        .get('.tab-details > div').contains('TO PURCHASE: ADD ONE OR MORE E-CERTIFICATES TO YOUR SHOPPING CART, AND CHECK OUT AS USUAL.')
                                        .get('.tab-details > div').contains('AFTER PAYMENT, PLEASE ALLOW 1 BUSINESS DAY FOR YOUR CERTIFICATE CODE TO BE GENERATED AND EMAILED TO YOU.')
                                        .get('.tab-details > div').contains('TO REDEEM: ENTER THE UNIQUE E-CERTIFICATE CODE IN THE GIFT CERTIFICATE SECTION AT CHECKOUT.')
                                        .get('.tab-details > div').contains('UPON REDEMPTION, THE CREDIT AMOUNT WILL BE APPLIED TO THE SHOPPING CART TOTAL.')
                                        .get('.tab-details > div').contains('GIFT CERTIFICATES HAVE NO EXPIRATION DATE')
                                        .get('[color="red"]').should('have.text' , 'Your official Splunk e-certificate will arrive to you via email in 24 hours and each one will have a unique code to be applied at checkout.')
                                      cy.go('back')

                                        .get('h4').eq(4).should('have.text' , 'SPK25-PURCH')
                                        .get('.item-title > a').eq(4).should('have.text' , '$25 Gift Certificate').click()
                                        .url().should('contain', 'SPK25-PURCH')
                                      cy.contains('$25 Gift Certificate')
                                        .get('h4 > span').should('have.text' , 'SPK25-PURCH')
                                        .get('.tab-details > div').contains('Give the gift of Splunk gear! This electronic gift certificate can be used toward the purchase of swag @ Splunk.Shop. Go ahead spend it all in one place!')
                                        .get('.tab-details > div').contains('TO PURCHASE: ADD ONE OR MORE E-CERTIFICATES TO YOUR SHOPPING CART, AND CHECK OUT AS USUAL.')
                                        .get('.tab-details > div').contains('AFTER PAYMENT, PLEASE ALLOW 1 BUSINESS DAY FOR YOUR CERTIFICATE CODE TO BE GENERATED AND EMAILED TO YOU.')
                                        .get('.tab-details > div').contains('TO REDEEM: ENTER THE UNIQUE E-CERTIFICATE CODE IN THE GIFT CERTIFICATE SECTION AT CHECKOUT.')
                                        .get('.tab-details > div').contains('UPON REDEMPTION, THE CREDIT AMOUNT WILL BE APPLIED TO THE SHOPPING CART TOTAL.')
                                        .get('.tab-details > div').contains('GIFT CERTIFICATES HAVE NO EXPIRATION DATE')
                                        .get('[color="red"]').should('have.text' , 'Your official Splunk e-certificate will arrive to you via email in 24 hours and each one will have a unique code to be applied at checkout.')
  }) 

                    
})
  })