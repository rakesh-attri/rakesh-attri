/// <reference types="Cypress" />

describe('HW help request create TTB', function() {
  
  // var i = 0;
  // for (i = 0; i < 10 ; i++) {  
  

    it('HW request ' , function()
    {
      cy.viewport('macbook-15')
      cy.clearCookies()
      cy.visit('http://192.168.0.171:30071/login?slug=dushyant70')
        .get('#email').type('aakarshan.sharma+31@sarvika.com')
        .get('#password').type('Test@1234')
        .get('[type="submit"]').click()
        .get('[data-bind="homeworkhelp"]').click()
        .get('#subject_id').click()
  
                    
                    let math = Math.floor(Math.random() * 10) + 0;
                    console.log(math)  
                  
                    
  
        cy.get('#subject_id-option-'+math).click()
        cy.contains('Next').click()
        cy.get('.MuiInputAdornment-root > .MuiButtonBase-root').click()
          .get(':nth-child(1) > :nth-child(4) > :nth-child(4) > .MuiButtonBase-root > .MuiIconButton-label').click()
          .get('.MuiDialogActions-root > :nth-child(2) > .MuiButton-label').click()
        cy.contains('Next').click()
          .get('#description').type('auto session')

            const filePath = 'resume.docx';
        cy.get('#request_documents').attachFile(filePath)
        cy.contains('Next').click()
        cy.get('.MuiButton-containedPrimary').click()
          .get('.jss161').click()
          .get('[data-bind="logout"]').click()
        cy.contains('confirm').click()
        
    })
  // }
  })