/// <reference types="Cypress" />

      
describe('AutoRegister', function() {


    const fnames = ['aakarshan' , 'aakrshan']
    const lnames = ['sharma' , 'shrma']
    const mails = ['test@yop.com' , 'test1@yop.com']
    const pwds = 'test1234'
  
  it('User Registration', function()
  {

    var i ;
    for (i = 0; i < fnames.length ; i++) {


    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://mypromomall.com/preview/graywear')
      
      .get('#create-new-account').click().wait(300)
      .url().should('contain', 'register.html')
      .get('[name="customerDTO.firstName"]').type(fnames[i])
      .get('[name="customerDTO.lastName"]').type(lnames[i])
      .get('[name="customerDTO.loginname"]').type(mails[i])
      .get('#confirmLogin').type(mails[i])
      .get('[name="customerDTO.loginpassword"]').type(pwds)
      .get('#confirmPassword').type(pwds)
      .get('#location_shopper_group').select('Gray Solutions')
      .get('#job_title').select('Office')
      .get('#new_hire').click()
    
  }
})
})
