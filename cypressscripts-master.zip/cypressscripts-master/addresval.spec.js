const urls = ['https://www.mypromomall.com/preview/arbyssmiles' ,'https://www.mypromomall.com/preview/rbamericanpromoshop' ,'https://www.mypromomall.com/preview/harley-davidson']
describe('Address Validation', () => {
  urls.forEach((url) => {
  	Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
})

    it(`Validation on ${url}`, () => {
      cy.viewport(1920, 937)
      cy.visit(url).wait(900)

      .get('#welcome-data').click().wait(300)
      .url().should('contain', 'signin.html')
      .get('#create-new-account').click().wait(300)
      .url().should('contain', 'register.html')
      .get('[name="customerDTO.firstName"]').type('Aakarshan')
      .get('[name="customerDTO.lastName"]').type('Tester')
      .get('[name="customerDTO.loginname"]').type('')
      .get('[name="confirmLogin"]').type('')
      .get('[name="customerDTO.loginpassword"]').type('')
      .get('[name="confirmPassword"]').type('')
      .get('[value="Continue"]').click().wait(900)
      .url().should('contain', 'store.html')
      // address validation from my account
      .get('#welcome-data').click().wait(300)
      .get('[name="billingAddress.address1"]').type('26601 ALISO CREEK RD')
      .get('[name="billingAddress.address2"]').type('STE D')
      .get('#country_id').select('USA')
      .get('#province').select('CALIFORNIA')
      .get('[name="billingAddress.city"]').type('ALISO VIEJO')
      .get('[name="billingAddress.postal"]').type('61081')
      //.get('.formpost').click().wait(300)
      .get('.label-btn > [type="button"]').click().wait(300)
    cy.contains('We were unable to validate the address you provided. You may continue with this address or use one of the suggested addresses below.')
      .get('.active > .list-group-item-text').contains('ALISO VIEJO')

    })
  })
})