const urls = ['20191106170' , '20190614439']
describe('Maintenance pop up', () => {
  urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
})

    it(`Maintenance pop up on ${url}`, () => {
      cy.viewport('macbook-15')
      cy.visit('www.mybrandmall.com/store.html?vid='+url).wait(900)

      .get('#ss_maintenance_msg').contains('This site will be down for scheduled maintenance on Saturday, January 11, 2020, until 7:00pm CST. Thank you!')
      

    })
  })
})

//  ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,'' ,''

