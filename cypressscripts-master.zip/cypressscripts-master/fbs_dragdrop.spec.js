describe('drag drop', function() {


  it('FBS' , function()
  {
    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('http://192.168.0.189')
      .get('#accountId').type('')
      .get('#username').type('')
      .get('#password').type('')
      .get('[type="submit"]').click().wait(100)
      .get('h2').contains('FormBuilder').click()
      .get(':nth-child(7) > .MuiButton-root > .MuiButton-label').eq(0).click()
      .get('.link-button-primary').click()
    cy.get('[data-type="textfield"]').drag('.builder-components')
      .get('.btn-success').click()

  })
})