const urls = ['20190723592', '20190715563', '20190523381' , '20190529389' , '20190410219' , '20190327172' , '20181119761' , '20181105714' , '20180315923' ,'20191101146']
describe('Create item verify', function() {

    urls.forEach((url) => {
    Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
})

  it(`PPE item on ${url}`, () => {
  

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://qa.mypromomall.com/preview/store.html?vid='+url).wait(900)
      .get('.covid19_close_btn').click()
    cy.contains('PPEKIT').click()
      .url().should('contain', '/shop/ppekit')
      .get('.item-title > a').eq(0).should('have.text' , 'PPE001').click()
      .url().should('contain', 'vid='+url)
      //.get('h2').should('have.text' , 'PPE0017')
    cy.contains('PPE001')
      .get('h4 > span').should('have.text' , 'PPE001')
      .get('.tab-details > div').should('have.text' , 'SEO PPE KIT')
      .get('.integer').should('have.text' , '$2')
      .get('.decimal').should('have.text' , '00')

      })

})
  })