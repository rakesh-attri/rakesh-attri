describe('Add item option item in cart', function() {Cypress.on('uncaught:exception', (err, runnable) => {
  // returning false here prevents Cypress from 
  // failing the test
  return false
})
  it('Add  to cart', function()

  {

    cy.viewport('macbook-15')
    cy.clearCookies()
    cy.visit('https://qa.mypromomall.com/preview/basestore_halo_v2')
      .get('#welcome-data').click().wait(300)
      .url().should('contain', 'signin.html')
      .get('[name="login"]').type('')
      .get('#password').type('')
      .get('[value="Login"]').click().wait(300)
      .get(':nth-child(2) > .search-form-btn').click()
      .get('#key').type('Mens Polo{enter}').wait(300)
      .url().should('contain', 'storeitem.html')
      .get('.attributeoption').eq(0).select('Blue')
      .get('.attributeoption').eq(1).select('Medium')
    cy.contains('Add to Cart').click().wait(300)
      
  })
})